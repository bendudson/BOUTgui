lst = ['a','b','c','d']

for i in range(len(lst)):
    length = len(lst)
    if i < length-1:
        print i
