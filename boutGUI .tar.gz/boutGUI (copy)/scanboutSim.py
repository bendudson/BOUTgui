#!/usr/bin/env python

from boututils import shell, launch, getmpirun
import sys, os, ConfigParser, shutil, fileinput
from tempfile import mkstemp
from os import remove
from shutil import move
from datetime import *



currentDir = os.getcwd()
config = currentDir + '/config/config.ini'


parser = ConfigParser.ConfigParser()
parser.read(config)
exe = parser.get('exe', 'path')
archive = parser.get('archive', 'path')
editor = parser.get('text editor', 'editor')
MPIRUN = getmpirun()
nargs = len(sys.argv)


# form of arguments: runid, key, subkey, initial, limit, increment, restart, initial2, limit2, key2, subkey2, increment2
# it is not necessary to have all the arguments, the "two's" make a twin scan where it increases one variable and then the other.



runid = sys.argv[1] + '/'

key = '[' + sys.argv[2] + ']'

if key == '[timing]':
  key = ''

subkey = sys.argv[3]

a = sys.argv[4]
initial = float(a)

b = sys.argv[5]
limit =float(b)

c = sys.argv[6]
increment = float(c)

restart = sys.argv[7]

incrementType = sys.argv[8]

# these variables are only defined
if nargs > 9:
  initial2 = sys.argv[9]
  initial2 = float(initial2)

  limit2 = sys.argv[10]
  limit2 = float(limit2)

  key2 = '[' + sys.argv[11] + ']'
  if key2 == '[timing]':
    key2 = ''
    

  subkey2 = sys.argv[12]

  increment2 = sys.argv[13]
  increment2 = float(increment2)

inctype = '%'



if nargs < 9:
    # prints help if arguements aren't given
    print("Format is: ")
    print("  %s <run id> [directory]")
    print("     directory - optional, default is 'tmp'")
    sys.exit(1)

# Unless an arguement is given a temporary folder is created to run in
if nargs > 9:
    directory = sys.argv[2]
else:
    directory = 'tmp'


# Confirms location of BOUT++ archive
try:
    archive = os.environ["BOUTARCHIVE"]
except KeyError:
    # No environment variable. Use default
    archive = '/hwdisks/home/lt724/BOUT-dev/archive/'

# Checks for a valid archive ID
def rundirectory(runid):   
    if os.path.exists(runid):
        print 'Valid runid', runid
    else:
        print 'Invalid runid', runid
        sys.exit(0)


def removeTiming(loadpath):
    f = open(loadpath, 'r')
    filedata = f.read()
    f.close()

    newdata = filedata.replace('[timing]','')


    with open(loadpath, 'w') as File:
        File.write(newdata)
        File.close()

def reverse2fluid(loadpath):
    for line in fileinput.input(loadpath, inplace = 1):
        
        if '[TWOfluid]' in line:
            line = line.replace('[TWOfluid]', '[2fluid]')
        sys.stdout.write(line)


# Makes a new directory called "tmp"
shell("mkdir " + directory) 
sourcedirectory = rundirectory(runid)



### directory = the runid
loadpath = directory + '/BOUT.inp'
loadfrom = runid

def scan(initial, limit, restart, loadpath, key, subkey, increment):
    global i, loadfrom
    inputfiles = os.listdir(loadfrom)
    for runfiles in inputfiles:
        filepath = os.path.join(loadfrom, runfiles)
        if os.path.isfile(filepath):
            shutil.copy(filepath, directory)
    removeTiming(directory + '/BOUT.inp')
    reverse2fluid(directory + '/BOUT.inp')
    #npro = raw_input('N.o of processors to use: ')
    cmd = exe + ' -d ' + directory + '/'
    print("Command = '%s'" % cmd)
    th, temp = mkstemp()
    with open(temp,'w') as g:
        with open(loadpath, 'r') as f:
            for line in f:
                if line.startswith(key):
                    g.write(line)
                    for line in f:
                        if line.startswith(subkey):
                            string = line.split()
                            a = string[string.index('=') + 1]
                            if i < 2:
                              final = initial
                            elif incrementType == '+':
                              final = initial + increment
                              initial = final
                            else:
                              final = initial * increment
                              initial = final
                            b = str(final)
                            new = line.replace(a, b)
                            initial = final
                            g.write(new)
                            break
                        else:
                            g.write(line)
                else:
                    g.write(line)
            g.close()
    remove(loadpath)
    move(temp, loadpath)
    if restart == 'y':
        launch(cmd + ' restart', nproc = 5, nice = 10)
    else:
        launch(cmd, nproc = 5, nice = 10, pipe=False)
    return initial


def run2(initial, limit, restart, loadpath, key, subkey, increment, initial2, limit2, key2, subkey2, increment2):
        newinitial1 =initial
        newinitial2 = initial2
        limit1 = limit
        global i
        i =1
        while newinitial1 < limit1:
          a = scan(newinitial1, limit, restart, loadpath, key, subkey, increment)
          newinitial1 = float(a)
          createfolder(subkey, newinitial1)
          b = scan(newinitial2,limit2,restart, loadpath, key2, subkey2, increment2)
          newinitial2 = float(b)
          createfolder(subkey2, newinitial2)
          i += 1


def run1(initial, limit, restart, loadpath, key, subkey, increment):
        newinitial1 =initial
        limit1 = limit
        global i
        i =1
        while newinitial1 < limit1:
          a = scan(newinitial1, limit, restart, loadpath, key, subkey, increment)
          newinitial1 = float(a)
          createfolder(subkey, newinitial1)
          i += 1
        
        
        
def createfolder(subkey, initial):      
    inputfiles = os.listdir(directory)
    list.sort(inputfiles)
    x = 1
    archive = (os.path.dirname(os.path.dirname(runid)))
    newfolder = str(archive) + '/' + str(subkey) + '.' + str(initial) + '.' + str(x) + '/'
    while os.path.isdir(newfolder):
        x = x + 1
        newfolder = str(archive) + '/' + str(subkey) + '.' + str(initial) + '.' + str(x) + '/'
    else:
        shell("mkdir " + newfolder)
    for file in inputfiles:
        if file.startswith('BOUT.'):
            filepath = os.path.join(directory, file)
            if os.path.isfile(filepath):
                shutil.copy(filepath, newfolder)
        if file.startswith('record.'):
            filepath = os.path.join(directory, file)
            if os.path.isfile(filepath):
                shutil.copy(filepath, newfolder)
        if file.startswith('usernotes.'):
            filepath = os.path.join(directory, file)
            if os.path.isfile(filepath):
                shutil.copy(filepath, newfolder)
    global loadfrom
    loadfrom = newfolder  

try:
  if limit2 != '':
    run2(initial, limit, restart, loadpath, key, subkey, increment, initial2, limit2, key2, subkey2, increment2)
  else:
    run1(initial, limit, restart, loadpath, key, subkey, increment)
    
except KeyboardInterrupt:
    print 'User Exit'
    shutil.rmtree('tmp')
    sys.exit(0)

